import React from 'react'
import Home1 from '../components/Home1'
import Conus from '../components/Conus'
import LeadershipTeam from '../components/LeadershipTeam'
import Sponser from '../components/Sponser'
import OurTeam from '../components/Ourtems/OurTeam'

const ExpertPage = () => {
  return (
    <div>
        <OurTeam/>
        <Home1/>
          <Conus/>
          <LeadershipTeam/>
        <Sponser/>
      
    </div>
  )
}

export default ExpertPage
